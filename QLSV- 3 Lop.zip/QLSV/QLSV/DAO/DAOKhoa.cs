﻿using QLSV.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLSV.DAO
{
    class DAOKhoa
    {
        SqlConnection conn;
        public void OpenConnect()
        {
            string strConnect = Connect.str;
            conn = new SqlConnection(strConnect);
            conn.Open();
        }
        public void CloseConnect()
        {
            conn.Close();
        }
        public void ThemK(DTOKhoa K)
        {
            OpenConnect();
            string insert = "insert into [xett5019_trochoi].[xett5019_trochoi].[Tb_khoa] values (@MaKhoa, @TenKhoa)";
            SqlCommand cmd = new SqlCommand(insert, conn);
            cmd.Parameters.Add(new SqlParameter("@MaMH", K.MaKhoa));
            cmd.Parameters.Add(new SqlParameter("@TenMH", K.TenKhoa));
            cmd.ExecuteNonQuery();
            CloseConnect();
        }
        public void SuaK(DTOKhoa L)
        {
            OpenConnect();
            string edit = "update [xett5019_trochoi].[xett5019_trochoi].[Tb_khoa] set tenkhoa=@TenKhoa where makhoa=@MaKhoa";
            SqlCommand cmd = new SqlCommand(edit, conn);
            cmd.Parameters.Add(new SqlParameter("@MaLop", L.MaKhoa));
            cmd.Parameters.Add(new SqlParameter("@TenLop", L.TenKhoa));
            cmd.ExecuteNonQuery();
            CloseConnect();
        }
        public void XoaK(string MaKhoa)
        {
            OpenConnect();
            string delete = "delete from [xett5019_trochoi].[xett5019_trochoi].[Tb_khoa] where makhoa=@MaLop";
            SqlCommand cmd = new SqlCommand(delete, conn);
            cmd.Parameters.Add(new SqlParameter("@MaKhoa", MaKhoa));
            cmd.ExecuteNonQuery();
            CloseConnect();
        }
        public DataTable HienThiDS()
        {
            OpenConnect();
            DataTable dt = new DataTable();
            string ht = "select * from [xett5019_trochoi].[xett5019_trochoi].[Tb_Khoa]";
            SqlCommand cmd = new SqlCommand(ht, conn);
            dt.Load(cmd.ExecuteReader());
            CloseConnect();
            return dt;
        }
    }
}
