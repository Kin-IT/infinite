﻿using QLSV.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLSV.DAO
{
    class DAOStudent
    {
        SqlConnection conn;
        public void OpenConnect()
        {
            string strConnect =Connect.str;
            conn = new SqlConnection(strConnect);
            conn.Open();
        }
        public void CloseConnect()
        {
            conn.Close();
        }
        public void ThemSinhVien(DTOStudent SV)
        {
            OpenConnect();
            string insert = "insert into [xett5019_trochoi].[dbo].[Tb_student] values (@MaSV, @TenSV, @Lop)";
            SqlCommand cmd = new SqlCommand(insert, conn);
            cmd.Parameters.Add(new SqlParameter("@MaSV", SV.MaSV));
            cmd.Parameters.Add(new SqlParameter("@TenSV", SV.TenSV));
            cmd.Parameters.Add(new SqlParameter("@Lop", SV.Lop));
            cmd.ExecuteNonQuery();
            CloseConnect();
        }
        public void SuaSinhVien(DTOStudent SV)
        {
            OpenConnect();
            string edit = "update [xett5019_trochoi].[dbo].[Tb_student] set hoten=@TenSV, lop=@Lop where mssv=@MaSV";
            SqlCommand cmd = new SqlCommand(edit, conn);
            cmd.Parameters.Add(new SqlParameter("@MaSV", SV.MaSV));
            cmd.Parameters.Add(new SqlParameter("@TenSV", SV.TenSV));
            cmd.Parameters.Add(new SqlParameter("@DiaChi", SV.Lop));
            cmd.ExecuteNonQuery();
            CloseConnect();
        }
        public void XoaSinhVien(string MaSV)
        {
            OpenConnect();
            string delete = "delete from [xett5019_trochoi].[dbo].[Tb_student] where mssv=@MaSV";
            SqlCommand cmd = new SqlCommand(delete, conn);
            cmd.Parameters.Add(new SqlParameter("@MaSV", MaSV));
            cmd.ExecuteNonQuery();
            CloseConnect();
        }
        public DataTable HienThiDS()
        {
            OpenConnect();
            DataTable dt = new DataTable();
            string ht = "select * from [xett5019_trochoi].[dbo].[Tb_student]";
            SqlCommand cmd = new SqlCommand(ht, conn);
            dt.Load(cmd.ExecuteReader());
            CloseConnect();
            return dt;
        }
    }
}
