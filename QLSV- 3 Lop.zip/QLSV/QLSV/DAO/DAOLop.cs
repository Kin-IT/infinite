﻿using QLSV.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLSV.DAO
{
    class DAOLop
    {
        SqlConnection conn;
        public void OpenConnect()
        {
            string strConnect = Connect.str;
            conn = new SqlConnection(strConnect);
            conn.Open();
        }
        public void CloseConnect()
        {
            conn.Close();
        }
        public void ThemLop(DTOLop L)
        {
            OpenConnect();
            string insert = "insert into [xett5019_trochoi].[xett5019_trochoi].[Tb_lop] values (@MaLop, @TenLop, @TenKhoa)";
            SqlCommand cmd = new SqlCommand(insert, conn);
            cmd.Parameters.Add(new SqlParameter("@MaMH", L.MaLop));
            cmd.Parameters.Add(new SqlParameter("@TenMH", L.TenLop));
            cmd.Parameters.Add(new SqlParameter("@TenKhoa", L.TenKhoa));
            cmd.ExecuteNonQuery();
            CloseConnect();
        }
        public void SuaLop(DTOLop L)
        {
            OpenConnect();
            string edit = "update [xett5019_trochoi].[xett5019_trochoi].[Tb_lop] set tenlop=@TenLop, tenkhoa=@TenKhoa where malop=@MaLop";
            SqlCommand cmd = new SqlCommand(edit, conn);
            cmd.Parameters.Add(new SqlParameter("@MaLop", L.MaLop));
            cmd.Parameters.Add(new SqlParameter("@TenLop", L.TenLop));
            cmd.Parameters.Add(new SqlParameter("@TenKhoa", L.TenKhoa));
            cmd.ExecuteNonQuery();
            CloseConnect();
        }
        public void XoaLop(string MaMH)
        {
            OpenConnect();
            string delete = "delete from [xett5019_trochoi].[xett5019_trochoi].[Tb_lop] where malop=@MaLop";
            SqlCommand cmd = new SqlCommand(delete, conn);
            cmd.Parameters.Add(new SqlParameter("@MaSV", MaMH));
            cmd.ExecuteNonQuery();
            CloseConnect();
        }
        public DataTable HienThiDS()
        {
            OpenConnect();
            DataTable dt = new DataTable();
            string ht = "select * from [xett5019_trochoi].[xett5019_trochoi].[Tb_lop]";
            SqlCommand cmd = new SqlCommand(ht, conn);
            dt.Load(cmd.ExecuteReader());
            CloseConnect();
            return dt;
        }
    }
}
