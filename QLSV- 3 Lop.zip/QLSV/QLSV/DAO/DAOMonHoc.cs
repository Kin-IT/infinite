﻿using QLSV.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLSV.DAO
{
    class DAOMonHoc
    {
        SqlConnection conn;
        public void OpenConnect()
        {
            string strConnect = Connect.str;
            conn = new SqlConnection(strConnect);
            conn.Open();
        }
        public void CloseConnect()
        {
            conn.Close();
        }
        public void ThemMonHoc(DTOMonHoc MH)
        {
            OpenConnect();
            string insert = "insert into [xett5019_trochoi].[dbo].[Tb_monhoc] values (@MaMH, @TenMH, @SoTC)";
            SqlCommand cmd = new SqlCommand(insert, conn);
            cmd.Parameters.Add(new SqlParameter("@MaMH", MH.MaMH));
            cmd.Parameters.Add(new SqlParameter("@TenMH", MH.TenMH));
            cmd.Parameters.Add(new SqlParameter("@SoTC", MH.SoTC));
            cmd.ExecuteNonQuery();
            CloseConnect();
        }
        public void SuaMonHoc(DTOMonHoc MH)
        {
            OpenConnect();
            string edit = "update [xett5019_trochoi].[dbo].[Tb_monhoc] set tenmh=@TenMH, sotinchi=@SoTC where mamh=@MaSV";
            SqlCommand cmd = new SqlCommand(edit, conn);
            cmd.Parameters.Add(new SqlParameter("@MaMH", MH.MaMH));
            cmd.Parameters.Add(new SqlParameter("@TenMH", MH.TenMH));
            cmd.Parameters.Add(new SqlParameter("@SoTC", MH.SoTC));
            cmd.ExecuteNonQuery();
            CloseConnect();
        }
        public void XoaMonHoc(string MaMH)
        {
            OpenConnect();
            string delete = "delete from [xett5019_trochoi].[dbo].[Tb_monhoc] where mamh=@MaSV";
            SqlCommand cmd = new SqlCommand(delete, conn);
            cmd.Parameters.Add(new SqlParameter("@MaSV", MaMH));
            cmd.ExecuteNonQuery();
            CloseConnect();
        }
        public DataTable HienThiDS()
        {
            OpenConnect();
            DataTable dt = new DataTable();
            string ht = "select * from [xett5019_trochoi].[dbo].[Tb_monhoc]";
            SqlCommand cmd = new SqlCommand(ht, conn);
            dt.Load(cmd.ExecuteReader());
            CloseConnect();
            return dt;
        }
    }
}
