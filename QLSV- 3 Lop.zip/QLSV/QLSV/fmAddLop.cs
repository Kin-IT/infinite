﻿using QLSV.BO;
using QLSV.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLSV
{
    public partial class fmAddLop : Form
    {
        BOLop bl = new BOLop();
        public fmAddLop()
        {
            InitializeComponent();
        }

        private void btnThucHien_Click(object sender, EventArgs e)
        {
            DTOLop L = new DTOLop(txbMaLop.Text, txbTenLop.Text, txbTenKhoa.Text);
            try
            {
                bl.ThemL(L);
                MessageBox.Show("Thêm thành công","Thông Báo",MessageBoxButtons.OK,MessageBoxIcon.None);
                ClearText();
            }
            catch
            {
                MessageBox.Show("Thêm Thất Bại","Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ClearText()
        {
            txbMaLop.Clear();
            txbTenKhoa.Clear();
            txbTenLop.Clear();
        }

        private void fmAddLop_Load(object sender, EventArgs e)
        {

        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
