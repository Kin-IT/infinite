﻿namespace QLSV
{
    partial class fmHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fmHome));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.pnHT = new System.Windows.Forms.Panel();
            this.tabView = new System.Windows.Forms.TabControl();
            this.tabTTSach = new System.Windows.Forms.TabPage();
            this.lsvHTSV = new System.Windows.Forms.ListView();
            this.MaSV = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.TenSV = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Lop = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnXoaSV = new System.Windows.Forms.Button();
            this.btnSuaSV = new System.Windows.Forms.Button();
            this.tabMonHoc = new System.Windows.Forms.TabPage();
            this.lsvMH = new System.Windows.Forms.ListView();
            this.MaMH = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.TenMH = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SoTC = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnXoaMH = new System.Windows.Forms.Button();
            this.btnSuaMH = new System.Windows.Forms.Button();
            this.tabLop = new System.Windows.Forms.TabPage();
            this.lsvLop = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnXoaLop = new System.Windows.Forms.Button();
            this.btnSuaLop = new System.Windows.Forms.Button();
            this.tabKhoa = new System.Windows.Forms.TabPage();
            this.btnRefrest = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnTimSach = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.btnBaoCao = new System.Windows.Forms.Button();
            this.btnTimKiemNangCao = new System.Windows.Forms.Button();
            this.btnThemLop = new System.Windows.Forms.Button();
            this.btnThemKhoa = new System.Windows.Forms.Button();
            this.btnThemMH = new System.Windows.Forms.Button();
            this.btnThemSV = new System.Windows.Forms.Button();
            this.lsvKhoa = new System.Windows.Forms.ListView();
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnXoaKhoa = new System.Windows.Forms.Button();
            this.btnSuaKhoa = new System.Windows.Forms.Button();
            this.quảnLyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.KiêmTratoolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.cậpNhậtNhânViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tạoTàiKhoảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.đổiMậtKhẩuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.đăngNhậpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cậpNhậtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cậpNhậtSáchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cậpNhậtToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.cậpNhậtTácGiảToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cậpNhậtLĩnhVựcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cậpNhậtNhàXuấtBảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.cậpNhậtThôngTinMượnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mượnSáchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.tácGiảToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nhàXuấtBảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lĩnhVựcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator14 = new System.Windows.Forms.ToolStripSeparator();
            this.sáchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.độcGiảToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tìmKiếmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tìmKiếmSáchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.tìmKiếmĐGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.báoCáoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tìnhTrạngSáchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.sốĐộcGiảToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trợGiúpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ExitToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.pnHT.SuspendLayout();
            this.tabView.SuspendLayout();
            this.tabTTSach.SuspendLayout();
            this.tabMonHoc.SuspendLayout();
            this.tabLop.SuspendLayout();
            this.tabKhoa.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.Window;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLyToolStripMenuItem,
            this.cậpNhậtToolStripMenuItem,
            this.mượnSáchToolStripMenuItem,
            this.tìmKiếmToolStripMenuItem,
            this.báoCáoToolStripMenuItem,
            this.trợGiúpToolStripMenuItem,
            this.ExitToolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1264, 24);
            this.menuStrip1.TabIndex = 10;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // pnHT
            // 
            this.pnHT.Controls.Add(this.tabView);
            this.pnHT.Controls.Add(this.btnRefrest);
            this.pnHT.Controls.Add(this.label1);
            this.pnHT.Controls.Add(this.btnTimSach);
            this.pnHT.Controls.Add(this.textBox1);
            this.pnHT.Controls.Add(this.panel1);
            this.pnHT.Location = new System.Drawing.Point(0, 27);
            this.pnHT.Name = "pnHT";
            this.pnHT.Size = new System.Drawing.Size(1264, 701);
            this.pnHT.TabIndex = 11;
            // 
            // tabView
            // 
            this.tabView.Controls.Add(this.tabTTSach);
            this.tabView.Controls.Add(this.tabMonHoc);
            this.tabView.Controls.Add(this.tabLop);
            this.tabView.Controls.Add(this.tabKhoa);
            this.tabView.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabView.Location = new System.Drawing.Point(160, 95);
            this.tabView.Name = "tabView";
            this.tabView.SelectedIndex = 0;
            this.tabView.Size = new System.Drawing.Size(1096, 600);
            this.tabView.TabIndex = 12;
            // 
            // tabTTSach
            // 
            this.tabTTSach.Controls.Add(this.lsvHTSV);
            this.tabTTSach.Controls.Add(this.btnXoaSV);
            this.tabTTSach.Controls.Add(this.btnSuaSV);
            this.tabTTSach.Location = new System.Drawing.Point(4, 25);
            this.tabTTSach.Name = "tabTTSach";
            this.tabTTSach.Padding = new System.Windows.Forms.Padding(3);
            this.tabTTSach.Size = new System.Drawing.Size(1088, 571);
            this.tabTTSach.TabIndex = 1;
            this.tabTTSach.Text = " Sinh Viên";
            this.tabTTSach.UseVisualStyleBackColor = true;
            // 
            // lsvHTSV
            // 
            this.lsvHTSV.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.MaSV,
            this.TenSV,
            this.Lop});
            this.lsvHTSV.FullRowSelect = true;
            this.lsvHTSV.GridLines = true;
            this.lsvHTSV.Location = new System.Drawing.Point(6, 6);
            this.lsvHTSV.Name = "lsvHTSV";
            this.lsvHTSV.Size = new System.Drawing.Size(1076, 497);
            this.lsvHTSV.TabIndex = 1;
            this.lsvHTSV.UseCompatibleStateImageBehavior = false;
            this.lsvHTSV.View = System.Windows.Forms.View.Details;
            // 
            // MaSV
            // 
            this.MaSV.Text = "Mã Sinh Viên";
            this.MaSV.Width = 200;
            // 
            // TenSV
            // 
            this.TenSV.Text = "Họ Tên Sinh Viên";
            this.TenSV.Width = 200;
            // 
            // Lop
            // 
            this.Lop.Text = "Lớp";
            this.Lop.Width = 200;
            // 
            // btnXoaSV
            // 
            this.btnXoaSV.BackColor = System.Drawing.Color.Cyan;
            this.btnXoaSV.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaSV.Location = new System.Drawing.Point(540, 525);
            this.btnXoaSV.Name = "btnXoaSV";
            this.btnXoaSV.Size = new System.Drawing.Size(143, 40);
            this.btnXoaSV.TabIndex = 0;
            this.btnXoaSV.Text = "Xóa Sinh Viên";
            this.btnXoaSV.UseVisualStyleBackColor = false;
            this.btnXoaSV.BindingContextChanged += new System.EventHandler(this.btnXoaSV_Click);
            this.btnXoaSV.Click += new System.EventHandler(this.btnXoaSV_Click_1);
            // 
            // btnSuaSV
            // 
            this.btnSuaSV.BackColor = System.Drawing.Color.Cyan;
            this.btnSuaSV.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuaSV.Location = new System.Drawing.Point(391, 525);
            this.btnSuaSV.Name = "btnSuaSV";
            this.btnSuaSV.Size = new System.Drawing.Size(143, 40);
            this.btnSuaSV.TabIndex = 0;
            this.btnSuaSV.Text = "Sửa Sinh Viên";
            this.btnSuaSV.UseVisualStyleBackColor = false;
            this.btnSuaSV.Click += new System.EventHandler(this.btnSuaSV_Click);
            // 
            // tabMonHoc
            // 
            this.tabMonHoc.Controls.Add(this.lsvMH);
            this.tabMonHoc.Controls.Add(this.btnXoaMH);
            this.tabMonHoc.Controls.Add(this.btnSuaMH);
            this.tabMonHoc.Location = new System.Drawing.Point(4, 25);
            this.tabMonHoc.Name = "tabMonHoc";
            this.tabMonHoc.Padding = new System.Windows.Forms.Padding(3);
            this.tabMonHoc.Size = new System.Drawing.Size(1088, 571);
            this.tabMonHoc.TabIndex = 2;
            this.tabMonHoc.Text = "Môn Học";
            this.tabMonHoc.UseVisualStyleBackColor = true;
            // 
            // lsvMH
            // 
            this.lsvMH.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.MaMH,
            this.TenMH,
            this.SoTC});
            this.lsvMH.FullRowSelect = true;
            this.lsvMH.GridLines = true;
            this.lsvMH.Location = new System.Drawing.Point(6, 6);
            this.lsvMH.Name = "lsvMH";
            this.lsvMH.Size = new System.Drawing.Size(1076, 497);
            this.lsvMH.TabIndex = 4;
            this.lsvMH.UseCompatibleStateImageBehavior = false;
            this.lsvMH.View = System.Windows.Forms.View.Details;
            // 
            // MaMH
            // 
            this.MaMH.Text = "Mã Môn Học";
            this.MaMH.Width = 200;
            // 
            // TenMH
            // 
            this.TenMH.Text = "Tên Môn Học";
            this.TenMH.Width = 200;
            // 
            // SoTC
            // 
            this.SoTC.Text = "Số Tính Chỉ";
            this.SoTC.Width = 200;
            // 
            // btnXoaMH
            // 
            this.btnXoaMH.BackColor = System.Drawing.Color.Cyan;
            this.btnXoaMH.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaMH.Location = new System.Drawing.Point(521, 525);
            this.btnXoaMH.Name = "btnXoaMH";
            this.btnXoaMH.Size = new System.Drawing.Size(143, 40);
            this.btnXoaMH.TabIndex = 2;
            this.btnXoaMH.Text = "Xóa Môn Học";
            this.btnXoaMH.UseVisualStyleBackColor = false;
            this.btnXoaMH.Click += new System.EventHandler(this.btnXoaMH_Click);
            // 
            // btnSuaMH
            // 
            this.btnSuaMH.BackColor = System.Drawing.Color.Cyan;
            this.btnSuaMH.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuaMH.Location = new System.Drawing.Point(372, 525);
            this.btnSuaMH.Name = "btnSuaMH";
            this.btnSuaMH.Size = new System.Drawing.Size(143, 40);
            this.btnSuaMH.TabIndex = 3;
            this.btnSuaMH.Text = "Sửa Sinh Môn Học";
            this.btnSuaMH.UseVisualStyleBackColor = false;
            // 
            // tabLop
            // 
            this.tabLop.Controls.Add(this.lsvLop);
            this.tabLop.Controls.Add(this.btnXoaLop);
            this.tabLop.Controls.Add(this.btnSuaLop);
            this.tabLop.Location = new System.Drawing.Point(4, 25);
            this.tabLop.Name = "tabLop";
            this.tabLop.Padding = new System.Windows.Forms.Padding(3);
            this.tabLop.Size = new System.Drawing.Size(1088, 571);
            this.tabLop.TabIndex = 3;
            this.tabLop.Text = " Lớp";
            this.tabLop.UseVisualStyleBackColor = true;
            // 
            // lsvLop
            // 
            this.lsvLop.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.lsvLop.FullRowSelect = true;
            this.lsvLop.GridLines = true;
            this.lsvLop.Location = new System.Drawing.Point(6, 6);
            this.lsvLop.Name = "lsvLop";
            this.lsvLop.Size = new System.Drawing.Size(1076, 497);
            this.lsvLop.TabIndex = 4;
            this.lsvLop.UseCompatibleStateImageBehavior = false;
            this.lsvLop.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Mã Lớp";
            this.columnHeader1.Width = 200;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Tên Lớp";
            this.columnHeader2.Width = 200;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Tên Khoa";
            this.columnHeader3.Width = 200;
            // 
            // btnXoaLop
            // 
            this.btnXoaLop.BackColor = System.Drawing.Color.Cyan;
            this.btnXoaLop.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaLop.Location = new System.Drawing.Point(556, 517);
            this.btnXoaLop.Name = "btnXoaLop";
            this.btnXoaLop.Size = new System.Drawing.Size(143, 40);
            this.btnXoaLop.TabIndex = 2;
            this.btnXoaLop.Text = "Xóa Lớp";
            this.btnXoaLop.UseVisualStyleBackColor = false;
            this.btnXoaLop.Click += new System.EventHandler(this.btnXoaLop_Click);
            // 
            // btnSuaLop
            // 
            this.btnSuaLop.BackColor = System.Drawing.Color.Cyan;
            this.btnSuaLop.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuaLop.Location = new System.Drawing.Point(407, 517);
            this.btnSuaLop.Name = "btnSuaLop";
            this.btnSuaLop.Size = new System.Drawing.Size(143, 40);
            this.btnSuaLop.TabIndex = 3;
            this.btnSuaLop.Text = "Sửa Lớp";
            this.btnSuaLop.UseVisualStyleBackColor = false;
            this.btnSuaLop.Click += new System.EventHandler(this.btnSuaLop_Click);
            // 
            // tabKhoa
            // 
            this.tabKhoa.Controls.Add(this.btnXoaKhoa);
            this.tabKhoa.Controls.Add(this.btnSuaKhoa);
            this.tabKhoa.Controls.Add(this.lsvKhoa);
            this.tabKhoa.Location = new System.Drawing.Point(4, 25);
            this.tabKhoa.Name = "tabKhoa";
            this.tabKhoa.Padding = new System.Windows.Forms.Padding(3);
            this.tabKhoa.Size = new System.Drawing.Size(1088, 571);
            this.tabKhoa.TabIndex = 4;
            this.tabKhoa.Text = "Khoa";
            this.tabKhoa.UseVisualStyleBackColor = true;
            // 
            // btnRefrest
            // 
            this.btnRefrest.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.btnRefrest.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefrest.Location = new System.Drawing.Point(894, 39);
            this.btnRefrest.Name = "btnRefrest";
            this.btnRefrest.Size = new System.Drawing.Size(143, 40);
            this.btnRefrest.TabIndex = 10;
            this.btnRefrest.Text = "Refrest";
            this.btnRefrest.UseVisualStyleBackColor = false;
            this.btnRefrest.Click += new System.EventHandler(this.btnRefrest_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(391, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 20);
            this.label1.TabIndex = 15;
            this.label1.Text = "Tìm Kiếm Nhanh";
            // 
            // btnTimSach
            // 
            this.btnTimSach.BackColor = System.Drawing.SystemColors.Control;
            this.btnTimSach.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimSach.Location = new System.Drawing.Point(787, 39);
            this.btnTimSach.Name = "btnTimSach";
            this.btnTimSach.Size = new System.Drawing.Size(101, 40);
            this.btnTimSach.TabIndex = 11;
            this.btnTimSach.Text = "Tìm";
            this.btnTimSach.UseVisualStyleBackColor = false;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(395, 46);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(373, 26);
            this.textBox1.TabIndex = 14;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.button8);
            this.panel1.Controls.Add(this.btnBaoCao);
            this.panel1.Controls.Add(this.btnTimKiemNangCao);
            this.panel1.Controls.Add(this.btnThemLop);
            this.panel1.Controls.Add(this.btnThemKhoa);
            this.panel1.Controls.Add(this.btnThemMH);
            this.panel1.Controls.Add(this.btnThemSV);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(143, 692);
            this.panel1.TabIndex = 13;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(-6, 181);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(157, 37);
            this.label2.TabIndex = 1;
            this.label2.Text = "=======";
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.White;
            this.button8.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(0, 313);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(143, 40);
            this.button8.TabIndex = 0;
            this.button8.UseVisualStyleBackColor = false;
            // 
            // btnBaoCao
            // 
            this.btnBaoCao.BackColor = System.Drawing.Color.White;
            this.btnBaoCao.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBaoCao.Location = new System.Drawing.Point(0, 267);
            this.btnBaoCao.Name = "btnBaoCao";
            this.btnBaoCao.Size = new System.Drawing.Size(143, 40);
            this.btnBaoCao.TabIndex = 0;
            this.btnBaoCao.Text = "Báo Cáo";
            this.btnBaoCao.UseVisualStyleBackColor = false;
            // 
            // btnTimKiemNangCao
            // 
            this.btnTimKiemNangCao.BackColor = System.Drawing.Color.White;
            this.btnTimKiemNangCao.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimKiemNangCao.Location = new System.Drawing.Point(0, 221);
            this.btnTimKiemNangCao.Name = "btnTimKiemNangCao";
            this.btnTimKiemNangCao.Size = new System.Drawing.Size(143, 40);
            this.btnTimKiemNangCao.TabIndex = 0;
            this.btnTimKiemNangCao.Text = "Tìm Kiếm Nâng Cao";
            this.btnTimKiemNangCao.UseVisualStyleBackColor = false;
            // 
            // btnThemLop
            // 
            this.btnThemLop.BackColor = System.Drawing.Color.White;
            this.btnThemLop.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemLop.Location = new System.Drawing.Point(0, 138);
            this.btnThemLop.Name = "btnThemLop";
            this.btnThemLop.Size = new System.Drawing.Size(143, 40);
            this.btnThemLop.TabIndex = 0;
            this.btnThemLop.Text = "Thêm Lớp";
            this.btnThemLop.UseVisualStyleBackColor = false;
            this.btnThemLop.Click += new System.EventHandler(this.btnThemLop_Click);
            // 
            // btnThemKhoa
            // 
            this.btnThemKhoa.BackColor = System.Drawing.Color.White;
            this.btnThemKhoa.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemKhoa.Location = new System.Drawing.Point(1, 92);
            this.btnThemKhoa.Name = "btnThemKhoa";
            this.btnThemKhoa.Size = new System.Drawing.Size(143, 40);
            this.btnThemKhoa.TabIndex = 0;
            this.btnThemKhoa.Text = "Thêm Khoa";
            this.btnThemKhoa.UseVisualStyleBackColor = false;
            this.btnThemKhoa.Click += new System.EventHandler(this.btnThemKhoa_Click);
            // 
            // btnThemMH
            // 
            this.btnThemMH.BackColor = System.Drawing.Color.White;
            this.btnThemMH.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemMH.Location = new System.Drawing.Point(0, 46);
            this.btnThemMH.Name = "btnThemMH";
            this.btnThemMH.Size = new System.Drawing.Size(143, 40);
            this.btnThemMH.TabIndex = 0;
            this.btnThemMH.Text = "Thêm Môn Học";
            this.btnThemMH.UseVisualStyleBackColor = false;
            this.btnThemMH.Click += new System.EventHandler(this.btnThemMH_Click);
            // 
            // btnThemSV
            // 
            this.btnThemSV.BackColor = System.Drawing.Color.White;
            this.btnThemSV.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemSV.Location = new System.Drawing.Point(0, 0);
            this.btnThemSV.Name = "btnThemSV";
            this.btnThemSV.Size = new System.Drawing.Size(143, 40);
            this.btnThemSV.TabIndex = 0;
            this.btnThemSV.Text = "Thêm Sinh Viên";
            this.btnThemSV.UseVisualStyleBackColor = false;
            this.btnThemSV.Click += new System.EventHandler(this.btnThemSV_Click);
            // 
            // lsvKhoa
            // 
            this.lsvKhoa.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader4,
            this.columnHeader5});
            this.lsvKhoa.FullRowSelect = true;
            this.lsvKhoa.GridLines = true;
            this.lsvKhoa.Location = new System.Drawing.Point(6, 6);
            this.lsvKhoa.Name = "lsvKhoa";
            this.lsvKhoa.Size = new System.Drawing.Size(1076, 497);
            this.lsvKhoa.TabIndex = 5;
            this.lsvKhoa.UseCompatibleStateImageBehavior = false;
            this.lsvKhoa.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Mã Khoa";
            this.columnHeader4.Width = 200;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Tên Khoa";
            this.columnHeader5.Width = 200;
            // 
            // btnXoaKhoa
            // 
            this.btnXoaKhoa.BackColor = System.Drawing.Color.Cyan;
            this.btnXoaKhoa.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaKhoa.Location = new System.Drawing.Point(555, 509);
            this.btnXoaKhoa.Name = "btnXoaKhoa";
            this.btnXoaKhoa.Size = new System.Drawing.Size(143, 40);
            this.btnXoaKhoa.TabIndex = 6;
            this.btnXoaKhoa.Text = "Xóa Khoa";
            this.btnXoaKhoa.UseVisualStyleBackColor = false;
            this.btnXoaKhoa.Click += new System.EventHandler(this.btnXoaKhoa_Click);
            // 
            // btnSuaKhoa
            // 
            this.btnSuaKhoa.BackColor = System.Drawing.Color.Cyan;
            this.btnSuaKhoa.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuaKhoa.Location = new System.Drawing.Point(406, 509);
            this.btnSuaKhoa.Name = "btnSuaKhoa";
            this.btnSuaKhoa.Size = new System.Drawing.Size(143, 40);
            this.btnSuaKhoa.TabIndex = 7;
            this.btnSuaKhoa.Text = "Sửa Khoa";
            this.btnSuaKhoa.UseVisualStyleBackColor = false;
            this.btnSuaKhoa.Click += new System.EventHandler(this.btnSuaKhoa_Click);
            // 
            // quảnLyToolStripMenuItem
            // 
            this.quảnLyToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.KiêmTratoolStripMenuItem1,
            this.toolStripSeparator7,
            this.cậpNhậtNhânViênToolStripMenuItem,
            this.toolStripSeparator1,
            this.tạoTàiKhoảnToolStripMenuItem,
            this.toolStripSeparator2,
            this.đổiMậtKhẩuToolStripMenuItem,
            this.toolStripSeparator3,
            this.đăngNhậpToolStripMenuItem});
            this.quảnLyToolStripMenuItem.Image = global::QLSV.Properties.Resources.onebit_01;
            this.quảnLyToolStripMenuItem.Name = "quảnLyToolStripMenuItem";
            this.quảnLyToolStripMenuItem.Size = new System.Drawing.Size(134, 20);
            this.quảnLyToolStripMenuItem.Text = "&Quản Lý Hệ Thống";
            // 
            // KiêmTratoolStripMenuItem1
            // 
            this.KiêmTratoolStripMenuItem1.Enabled = false;
            this.KiêmTratoolStripMenuItem1.Name = "KiêmTratoolStripMenuItem1";
            this.KiêmTratoolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.K)));
            this.KiêmTratoolStripMenuItem1.Size = new System.Drawing.Size(236, 22);
            this.KiêmTratoolStripMenuItem1.Text = "Kiểm Tra TT Nhân Viên";
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(233, 6);
            // 
            // cậpNhậtNhânViênToolStripMenuItem
            // 
            this.cậpNhậtNhânViênToolStripMenuItem.Enabled = false;
            this.cậpNhậtNhânViênToolStripMenuItem.Name = "cậpNhậtNhânViênToolStripMenuItem";
            this.cậpNhậtNhânViênToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.cậpNhậtNhânViênToolStripMenuItem.Size = new System.Drawing.Size(236, 22);
            this.cậpNhậtNhânViênToolStripMenuItem.Text = "Cập Nhật Nhân Viên";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(233, 6);
            // 
            // tạoTàiKhoảnToolStripMenuItem
            // 
            this.tạoTàiKhoảnToolStripMenuItem.Name = "tạoTàiKhoảnToolStripMenuItem";
            this.tạoTàiKhoảnToolStripMenuItem.Size = new System.Drawing.Size(236, 22);
            this.tạoTàiKhoảnToolStripMenuItem.Text = "Tạo Tài Khoản";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(233, 6);
            // 
            // đổiMậtKhẩuToolStripMenuItem
            // 
            this.đổiMậtKhẩuToolStripMenuItem.Enabled = false;
            this.đổiMậtKhẩuToolStripMenuItem.Name = "đổiMậtKhẩuToolStripMenuItem";
            this.đổiMậtKhẩuToolStripMenuItem.Size = new System.Drawing.Size(236, 22);
            this.đổiMậtKhẩuToolStripMenuItem.Text = "Đổi Mật Khẩu";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(233, 6);
            // 
            // đăngNhậpToolStripMenuItem
            // 
            this.đăngNhậpToolStripMenuItem.Name = "đăngNhậpToolStripMenuItem";
            this.đăngNhậpToolStripMenuItem.Size = new System.Drawing.Size(236, 22);
            this.đăngNhậpToolStripMenuItem.Text = "Đăng Nhập";
            // 
            // cậpNhậtToolStripMenuItem
            // 
            this.cậpNhậtToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cậpNhậtSáchToolStripMenuItem,
            this.cậpNhậtToolStripMenuItem1,
            this.toolStripSeparator8,
            this.cậpNhậtTácGiảToolStripMenuItem,
            this.cậpNhậtLĩnhVựcToolStripMenuItem,
            this.cậpNhậtNhàXuấtBảnToolStripMenuItem,
            this.toolStripSeparator4,
            this.cậpNhậtThôngTinMượnToolStripMenuItem});
            this.cậpNhậtToolStripMenuItem.Image = global::QLSV.Properties.Resources._8;
            this.cậpNhậtToolStripMenuItem.Name = "cậpNhậtToolStripMenuItem";
            this.cậpNhậtToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.cậpNhậtToolStripMenuItem.Size = new System.Drawing.Size(85, 20);
            this.cậpNhậtToolStripMenuItem.Text = "Cập Nhật";
            // 
            // cậpNhậtSáchToolStripMenuItem
            // 
            this.cậpNhậtSáchToolStripMenuItem.Name = "cậpNhậtSáchToolStripMenuItem";
            this.cậpNhậtSáchToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.cậpNhậtSáchToolStripMenuItem.Size = new System.Drawing.Size(262, 22);
            this.cậpNhậtSáchToolStripMenuItem.Text = "Cập Nhật Sinh Viên";
            // 
            // cậpNhậtToolStripMenuItem1
            // 
            this.cậpNhậtToolStripMenuItem1.Enabled = false;
            this.cậpNhậtToolStripMenuItem1.Name = "cậpNhậtToolStripMenuItem1";
            this.cậpNhậtToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D)));
            this.cậpNhậtToolStripMenuItem1.Size = new System.Drawing.Size(262, 22);
            this.cậpNhậtToolStripMenuItem1.Text = "Cập Nhật Độc Giả";
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(259, 6);
            // 
            // cậpNhậtTácGiảToolStripMenuItem
            // 
            this.cậpNhậtTácGiảToolStripMenuItem.Enabled = false;
            this.cậpNhậtTácGiảToolStripMenuItem.Name = "cậpNhậtTácGiảToolStripMenuItem";
            this.cậpNhậtTácGiảToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.T)));
            this.cậpNhậtTácGiảToolStripMenuItem.Size = new System.Drawing.Size(262, 22);
            this.cậpNhậtTácGiảToolStripMenuItem.Text = "Cập Nhật Tác Giả";
            // 
            // cậpNhậtLĩnhVựcToolStripMenuItem
            // 
            this.cậpNhậtLĩnhVựcToolStripMenuItem.Enabled = false;
            this.cậpNhậtLĩnhVựcToolStripMenuItem.Name = "cậpNhậtLĩnhVựcToolStripMenuItem";
            this.cậpNhậtLĩnhVựcToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.L)));
            this.cậpNhậtLĩnhVựcToolStripMenuItem.Size = new System.Drawing.Size(262, 22);
            this.cậpNhậtLĩnhVựcToolStripMenuItem.Text = "Cập Nhật Lĩnh Vực";
            // 
            // cậpNhậtNhàXuấtBảnToolStripMenuItem
            // 
            this.cậpNhậtNhàXuấtBảnToolStripMenuItem.Enabled = false;
            this.cậpNhậtNhàXuấtBảnToolStripMenuItem.Name = "cậpNhậtNhàXuấtBảnToolStripMenuItem";
            this.cậpNhậtNhàXuấtBảnToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.cậpNhậtNhàXuấtBảnToolStripMenuItem.Size = new System.Drawing.Size(262, 22);
            this.cậpNhậtNhàXuấtBảnToolStripMenuItem.Text = "Cập Nhật Nhà Xuất Bản";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(259, 6);
            // 
            // cậpNhậtThôngTinMượnToolStripMenuItem
            // 
            this.cậpNhậtThôngTinMượnToolStripMenuItem.Enabled = false;
            this.cậpNhậtThôngTinMượnToolStripMenuItem.Name = "cậpNhậtThôngTinMượnToolStripMenuItem";
            this.cậpNhậtThôngTinMượnToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.M)));
            this.cậpNhậtThôngTinMượnToolStripMenuItem.Size = new System.Drawing.Size(262, 22);
            this.cậpNhậtThôngTinMượnToolStripMenuItem.Text = "Cập Nhật Thông Tin Mượn";
            // 
            // mượnSáchToolStripMenuItem
            // 
            this.mượnSáchToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator11,
            this.tácGiảToolStripMenuItem,
            this.nhàXuấtBảnToolStripMenuItem,
            this.lĩnhVựcToolStripMenuItem,
            this.toolStripSeparator14,
            this.sáchToolStripMenuItem,
            this.độcGiảToolStripMenuItem});
            this.mượnSáchToolStripMenuItem.Image = global::QLSV.Properties.Resources.onebit_50;
            this.mượnSáchToolStripMenuItem.Name = "mượnSáchToolStripMenuItem";
            this.mượnSáchToolStripMenuItem.Size = new System.Drawing.Size(87, 20);
            this.mượnSáchToolStripMenuItem.Text = "Thông tin";
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(143, 6);
            // 
            // tácGiảToolStripMenuItem
            // 
            this.tácGiảToolStripMenuItem.Enabled = false;
            this.tácGiảToolStripMenuItem.Name = "tácGiảToolStripMenuItem";
            this.tácGiảToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.tácGiảToolStripMenuItem.Text = "Tác Giả";
            // 
            // nhàXuấtBảnToolStripMenuItem
            // 
            this.nhàXuấtBảnToolStripMenuItem.Enabled = false;
            this.nhàXuấtBảnToolStripMenuItem.Name = "nhàXuấtBảnToolStripMenuItem";
            this.nhàXuấtBảnToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.nhàXuấtBảnToolStripMenuItem.Text = "Nhà Xuất Bản";
            // 
            // lĩnhVựcToolStripMenuItem
            // 
            this.lĩnhVựcToolStripMenuItem.Enabled = false;
            this.lĩnhVựcToolStripMenuItem.Name = "lĩnhVựcToolStripMenuItem";
            this.lĩnhVựcToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.lĩnhVựcToolStripMenuItem.Text = "Lĩnh Vực";
            // 
            // toolStripSeparator14
            // 
            this.toolStripSeparator14.Name = "toolStripSeparator14";
            this.toolStripSeparator14.Size = new System.Drawing.Size(143, 6);
            // 
            // sáchToolStripMenuItem
            // 
            this.sáchToolStripMenuItem.Enabled = false;
            this.sáchToolStripMenuItem.Name = "sáchToolStripMenuItem";
            this.sáchToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.sáchToolStripMenuItem.Text = "Sách";
            // 
            // độcGiảToolStripMenuItem
            // 
            this.độcGiảToolStripMenuItem.Enabled = false;
            this.độcGiảToolStripMenuItem.Name = "độcGiảToolStripMenuItem";
            this.độcGiảToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.độcGiảToolStripMenuItem.Text = "Độc Giả";
            // 
            // tìmKiếmToolStripMenuItem
            // 
            this.tìmKiếmToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tìmKiếmSáchToolStripMenuItem,
            this.toolStripSeparator5,
            this.tìmKiếmĐGToolStripMenuItem});
            this.tìmKiếmToolStripMenuItem.Image = global::QLSV.Properties.Resources.onebit_02;
            this.tìmKiếmToolStripMenuItem.Name = "tìmKiếmToolStripMenuItem";
            this.tìmKiếmToolStripMenuItem.Size = new System.Drawing.Size(86, 20);
            this.tìmKiếmToolStripMenuItem.Text = "Tìm Kiếm";
            // 
            // tìmKiếmSáchToolStripMenuItem
            // 
            this.tìmKiếmSáchToolStripMenuItem.Enabled = false;
            this.tìmKiếmSáchToolStripMenuItem.Name = "tìmKiếmSáchToolStripMenuItem";
            this.tìmKiếmSáchToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F)));
            this.tìmKiếmSáchToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.tìmKiếmSáchToolStripMenuItem.Text = "Tìm Kiếm Sách";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(190, 6);
            // 
            // tìmKiếmĐGToolStripMenuItem
            // 
            this.tìmKiếmĐGToolStripMenuItem.Enabled = false;
            this.tìmKiếmĐGToolStripMenuItem.Name = "tìmKiếmĐGToolStripMenuItem";
            this.tìmKiếmĐGToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.G)));
            this.tìmKiếmĐGToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.tìmKiếmĐGToolStripMenuItem.Text = "Tìm Kiếm ĐG";
            // 
            // báoCáoToolStripMenuItem
            // 
            this.báoCáoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tìnhTrạngSáchToolStripMenuItem,
            this.toolStripSeparator6,
            this.sốĐộcGiảToolStripMenuItem});
            this.báoCáoToolStripMenuItem.Image = global::QLSV.Properties.Resources.onebit_05;
            this.báoCáoToolStripMenuItem.Name = "báoCáoToolStripMenuItem";
            this.báoCáoToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.báoCáoToolStripMenuItem.Text = "Báo Cáo";
            // 
            // tìnhTrạngSáchToolStripMenuItem
            // 
            this.tìnhTrạngSáchToolStripMenuItem.Name = "tìnhTrạngSáchToolStripMenuItem";
            this.tìnhTrạngSáchToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.tìnhTrạngSáchToolStripMenuItem.Text = "Tình Trạng Sách";
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(172, 6);
            // 
            // sốĐộcGiảToolStripMenuItem
            // 
            this.sốĐộcGiảToolStripMenuItem.Name = "sốĐộcGiảToolStripMenuItem";
            this.sốĐộcGiảToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.sốĐộcGiảToolStripMenuItem.Text = "Tình Trạng Độc Giả";
            // 
            // trợGiúpToolStripMenuItem
            // 
            this.trợGiúpToolStripMenuItem.Image = global::QLSV.Properties.Resources.onebit_07;
            this.trợGiúpToolStripMenuItem.Name = "trợGiúpToolStripMenuItem";
            this.trợGiúpToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
            this.trợGiúpToolStripMenuItem.Text = "Trợ Giúp";
            // 
            // ExitToolStripMenuItem1
            // 
            this.ExitToolStripMenuItem1.Image = global::QLSV.Properties.Resources.onebit_35;
            this.ExitToolStripMenuItem1.Name = "ExitToolStripMenuItem1";
            this.ExitToolStripMenuItem1.Size = new System.Drawing.Size(66, 20);
            this.ExitToolStripMenuItem1.Text = "Thoát";
            this.ExitToolStripMenuItem1.Click += new System.EventHandler(this.ExitToolStripMenuItem1_Click);
            // 
            // fmHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 728);
            this.Controls.Add(this.pnHT);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "fmHome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản Lý Sinh Viên";
            this.Load += new System.EventHandler(this.fmHome_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.pnHT.ResumeLayout(false);
            this.pnHT.PerformLayout();
            this.tabView.ResumeLayout(false);
            this.tabTTSach.ResumeLayout(false);
            this.tabMonHoc.ResumeLayout(false);
            this.tabLop.ResumeLayout(false);
            this.tabKhoa.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem quảnLyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem KiêmTratoolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem cậpNhậtNhânViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem tạoTàiKhoảnToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem đổiMậtKhẩuToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem đăngNhậpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cậpNhậtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cậpNhậtSáchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cậpNhậtToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripMenuItem cậpNhậtTácGiảToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cậpNhậtLĩnhVựcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cậpNhậtNhàXuấtBảnToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem cậpNhậtThôngTinMượnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mượnSáchToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripMenuItem tácGiảToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nhàXuấtBảnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lĩnhVựcToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator14;
        private System.Windows.Forms.ToolStripMenuItem sáchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem độcGiảToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tìmKiếmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tìmKiếmSáchToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem tìmKiếmĐGToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem báoCáoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tìnhTrạngSáchToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem sốĐộcGiảToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trợGiúpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ExitToolStripMenuItem1;
        private System.Windows.Forms.Panel pnHT;
        private System.Windows.Forms.TabControl tabView;
        private System.Windows.Forms.TabPage tabTTSach;
        private System.Windows.Forms.ListView lsvHTSV;
        private System.Windows.Forms.ColumnHeader MaSV;
        private System.Windows.Forms.ColumnHeader TenSV;
        private System.Windows.Forms.ColumnHeader Lop;
        private System.Windows.Forms.Button btnXoaSV;
        private System.Windows.Forms.Button btnSuaSV;
        private System.Windows.Forms.TabPage tabMonHoc;
        private System.Windows.Forms.ListView lsvMH;
        private System.Windows.Forms.ColumnHeader MaMH;
        private System.Windows.Forms.ColumnHeader TenMH;
        private System.Windows.Forms.ColumnHeader SoTC;
        private System.Windows.Forms.Button btnXoaMH;
        private System.Windows.Forms.Button btnSuaMH;
        private System.Windows.Forms.TabPage tabLop;
        private System.Windows.Forms.ListView lsvLop;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.Button btnXoaLop;
        private System.Windows.Forms.Button btnSuaLop;
        private System.Windows.Forms.TabPage tabKhoa;
        private System.Windows.Forms.Button btnRefrest;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnTimSach;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button btnBaoCao;
        private System.Windows.Forms.Button btnTimKiemNangCao;
        private System.Windows.Forms.Button btnThemLop;
        private System.Windows.Forms.Button btnThemKhoa;
        private System.Windows.Forms.Button btnThemMH;
        private System.Windows.Forms.Button btnThemSV;
        private System.Windows.Forms.Button btnXoaKhoa;
        private System.Windows.Forms.Button btnSuaKhoa;
        private System.Windows.Forms.ListView lsvKhoa;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
    }
}