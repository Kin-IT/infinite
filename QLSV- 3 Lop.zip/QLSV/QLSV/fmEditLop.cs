﻿using QLSV.BO;
using QLSV.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLSV
{
    public partial class fmEditLop : Form
    {
        BOLop bl = new BOLop();

        public fmEditLop()
        {
            InitializeComponent();
        }

        private void fmEditLop_Load(object sender, EventArgs e)
        {
            DataTable dt = bl.HienThiDS();
            this.txbMaLop.Text = dt.Rows[0][0].ToString();
            this.txbTenLop.Text = dt.Rows[0][1].ToString();
            this.txbTenKhoa.Text = dt.Rows[0][2].ToString();
        }

        private void btnThucHien_Click(object sender, EventArgs e)
        {
            DTOLop SV = new DTOLop(txbMaLop.Text, txbTenLop.Text, txbTenKhoa.Text);
            try
            {
                bl.SuaL(SV);
                MessageBox.Show("Sửa thành công","Thông Báo",MessageBoxButtons.OK,MessageBoxIcon.None);
                this.Close();
            }
            catch
            {
                MessageBox.Show("Sửa không thành công");
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
