﻿using QLSV.BO;
using QLSV.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLSV
{
    public partial class fmAddMonHoc : Form
    {
        BOMonHoc bmh = new BOMonHoc();
        public fmAddMonHoc()
        {
            InitializeComponent();
        }

        private void fmAddMonHoc_Load(object sender, EventArgs e)
        {
            
        }
        private void ClearText()
        {
            txbMaMH.Clear();
            txbSoTC.Clear();
            txbTenMH.Clear();
        }
        private void btnThucHien_Click(object sender, EventArgs e)
        {
            DTOMonHoc MH = new DTOMonHoc(txbMaMH.Text, txbTenMH.Text, txbSoTC.Text);
            try
            {
                bmh.ThemMH(MH);
                MessageBox.Show("Thêm thành công");
                ClearText();
            }
            catch
            {
                MessageBox.Show("Thêm Thất Bại");
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
