﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLSV
{
    public partial class fmLogin : Form
    {
        public fmLogin()
        {
            InitializeComponent();
        }
        #region Method ()
        private void ClearSign()
        {
            txbPassword2.Clear();
            txbUsername2.Clear();
            txbPassword3.Clear();
        }
        private void ONSign()
        {
            gbDangKy.Enabled = true;
            btnSign.Enabled = false;
        }
        private void OFFSign()
        {
            gbDangKy.Enabled = false;
            btnSign.Enabled = true;
            
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            OFFSign();
        }

        private void btnSign_Click(object sender, EventArgs e)
        {
            ONSign();
        }

        private void btnHuyDK_Click(object sender, EventArgs e)
        {
            OFFSign();
            ClearSign();
        }
        private void ShowHome()
        {
            fmHome f = new fmHome();
            f.ShowDialog();
        }
        public bool checkSign()
        {
            if (string.IsNullOrEmpty(txbUsername2.Text))
            {
                MessageBox.Show("Bạn chưa nhập Tên Đăng Nhập.", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txbUsername2.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txbPassword2.Text))
            {
                MessageBox.Show("Bạn chưa nhập Mật Khẩu.", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txbPassword2.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txbPassword3.Text))
            {
                MessageBox.Show("Bạn chưa nhập lại Mật Khẩu.", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txbPassword3.Focus();
                return false;
            }
            return true;
        }
        public bool checkLogin()
        {
            if (string.IsNullOrEmpty(txbUsername.Text))
            {
                MessageBox.Show("Bạn chưa nhập Tên Đăng Nhập.", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txbUsername2.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txbPassword.Text))
            {
                MessageBox.Show("Bạn chưa nhập Mật Khẩu.", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txbPassword2.Focus();
                return false;
            }
            return true;
        }
        #endregion Method 
        #region Event_Click()
        private void btnLogin_Click(object sender, EventArgs e)
        {
            Login lg = new Login();
            if (checkLogin())
            {
                if (lg.DangNhap(txbUsername.Text, txbPassword.Text) == true)
                {
                    
                    MessageBox.Show("Xin Chào '"+ txbUsername.Text+"' ", "Đăng Nhập Thành Công", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    Thread thread = new Thread(new ThreadStart(ShowHome)); //Tạo luồng mới
                    thread.Start(); //Khởi chạy luồng
                    this.Close(); //đóng Form Login

                }
                else
                    MessageBox.Show("Thông Tin Không Đúng.Xin vui Lòng Kiểm Tra Lại", "Lỗi Đăng Nhập", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }
        private void btnDangKy2_Click(object sender, EventArgs e)
        {
            Sign sg = new Sign();
            int s = Convert.ToInt32(txbPassword3.Text);
            if (checkSign())
            {
                if (sg.DangKy(txbUsername2.Text,txbPassword2.Text)==true)
                {
                    if (txbPassword2.Text == txbPassword3.Text)
                    {
                        MessageBox.Show("Xin Chào '" + txbUsername2.Text + "'", "Đăng Ký Thành Công", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txbUsername.Text = txbUsername2.Text;
                        ClearSign();
                    }
                    else
                        MessageBox.Show("Mật Khẩu Không Trùng", "Lỗi");
                   
                }
                else
                    MessageBox.Show("Đã có tồn tại tài khoản này", "Lỗi Đăng Đăng Ký", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion Event_Click()
    }
}
