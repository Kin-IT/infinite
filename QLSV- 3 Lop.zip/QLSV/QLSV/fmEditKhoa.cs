﻿using QLSV.BO;
using QLSV.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLSV
{
    public partial class fmEditKhoa : Form
    {
        BOKhoa dk = new BOKhoa();
        public fmEditKhoa()
        {
            InitializeComponent();
        }

        private void btnThucHien_Click(object sender, EventArgs e)
        {
            DTOKhoa K = new DTOKhoa(txbMaKhoa.Text, txbTenKhoa.Text);
            try
            {
                dk.ThemKhoa(K);
                MessageBox.Show("Thêm thành công", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.None);
                ClearText();
            }
            catch
            {
                MessageBox.Show("Thêm Thất Bại", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ClearText()
        {
            txbMaKhoa.Clear();
            txbTenKhoa.Clear();
        }
    }
}
