﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLSV
{
    class Connect
    {
        public static string str = @"Data Source=112.78.2.78,1433;Initial Catalog=xett5019_trochoi;User ID=xett5019_trochoi;Password=17Dcntta@;Integrated Security=False";
    }
}
