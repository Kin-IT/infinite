﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLSV
{
    class Sign
    {
       
        public bool DangKy(string UserName, string Password)
        {
            try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = Connect.str;
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "INSERT INTO Tb_user VALUES('" + UserName + "','" + Password + "')";
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception)
            {

                return false;
            }
           

            return true;
        }
    }
}
