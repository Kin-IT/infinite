﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLSV.DTO
{
    class DTOKhoa
    {
        private string _TenKhoa;
        private string _MaKhoa;
        public string TenKhoa
        {
            get { return _TenKhoa; }
            set { _TenKhoa = value; }
        }
        public string MaKhoa
        {
            get { return _MaKhoa; }
            set { _MaKhoa = value; }
        }
       
        public DTOKhoa(string pMaKhoa, string pTenKhoa)
        {
            this._MaKhoa = pMaKhoa;
            this._TenKhoa = pTenKhoa;
          
        }
    }
}
