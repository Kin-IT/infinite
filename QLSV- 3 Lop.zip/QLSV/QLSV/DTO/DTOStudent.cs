﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLSV.DTO
{
    class DTOStudent
    {
        private string _MaSV;
        private string _Lop;
        private string _TenSV;

        public string MaSV
        {
            get { return _MaSV; }
            set { _MaSV = value; }
        }
        public string TenSV
        {
            get { return _TenSV; }
            set { _TenSV = value; }
        }
        public string Lop
        {
            get { return _Lop; }
            set { _Lop = value; }
        }
        public DTOStudent(string pMaSV, string pTenSV, string pLop)
        {
            this._MaSV = pMaSV;
            this._TenSV = pTenSV;
            this._Lop = pLop;
        }
    }
}
