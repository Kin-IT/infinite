﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLSV.DTO
{
    class DTOLop
    {
        private string _TenLop;
        private string _MaLop;
        private string _TenKhoa;

        public string TenLop
        {
            get { return _TenLop; }
            set { _TenLop = value; }
        }
        public string MaLop
        {
            get { return _MaLop; }
            set { _MaLop = value; }
        }
        public string TenKhoa
        {
            get { return _TenKhoa; }
            set { _TenKhoa = value; }
        }
        public DTOLop(string pMaLop, string pTenLop, string pTenKhoa)
        {
            this._MaLop = pMaLop;
            this._TenLop = pTenLop;
            this._TenKhoa = pTenKhoa;
        }
    }
}
