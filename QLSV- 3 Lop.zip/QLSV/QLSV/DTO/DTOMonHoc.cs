﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLSV.DTO
{
    class DTOMonHoc
    {
        private string _TenMH;
        private string _MaMH;
        private string _SoTC;

        public string TenMH
        {
            get { return _TenMH; }
            set { _TenMH = value; }
        }
        public string MaMH
        {
            get { return _MaMH; }
            set { _MaMH = value; }
        }
        public string SoTC
        {
            get { return _SoTC; }
            set { _SoTC = value; }
        }
        public DTOMonHoc(string pMaMH, string pTenMH, string pSoTC)
        {
            this._MaMH = pMaMH;
            this._TenMH = pTenMH;
            this._SoTC = pSoTC;
        }
    }
}
