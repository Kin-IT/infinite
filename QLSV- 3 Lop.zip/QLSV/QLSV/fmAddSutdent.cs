﻿using QLSV.BO;
using QLSV.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLSV
{
    public partial class fmAddSutdent : Form
    {
        BOStudent bmh = new BOStudent();
        public fmAddSutdent()
        {
            InitializeComponent();
        }
        private void ClearText()
        {
            txbMaSV.Clear();
            txbLop.Clear();
            txbTenSV.Clear();
        }
        private void btnThucHien_Click(object sender, EventArgs e)
        {
            DTOStudent SV = new DTOStudent(txbMaSV.Text, txbTenSV.Text, txbLop.Text);
            try
            {
                bmh.ThemSinhVien(SV);
                MessageBox.Show("Thêm thành công");
                ClearText();
            }
            catch
            {
                MessageBox.Show("Thêm Thất Bại");
            }
        }
    }
}
