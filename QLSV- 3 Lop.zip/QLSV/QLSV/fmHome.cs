﻿using QLSV.BO;
using QLSV.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLSV
{
    public partial class fmHome : Form
    {
        BOStudent bsv = new BOStudent();
        BOMonHoc bmh = new BOMonHoc();
        BOLop bl = new BOLop();
        BOKhoa dk = new BOKhoa();
        public fmHome()
        {
            InitializeComponent();
        }

        public void LoadSinhVien()
        {
            DataTable dt = bsv.HienThiDS();
            //Tải dữ liệu Sinh Viên 
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                ListViewItem item = new ListViewItem(dt.Rows[i][0].ToString());
                item.SubItems.Add(dt.Rows[i][1].ToString());
                item.SubItems.Add(dt.Rows[i][2].ToString());
                lsvHTSV.Items.Add(item);
            }
        }
        public void LoadMonMH()
        {
            DataTable dt = bmh.HienThiDS();
            //Tải dữ liệu Lớp
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                ListViewItem item = new ListViewItem(dt.Rows[i][0].ToString());
                item.SubItems.Add(dt.Rows[i][1].ToString());
                item.SubItems.Add(dt.Rows[i][2].ToString());
                lsvMH.Items.Add(item);
            }
        }
        public void LoadLop()
        {
            DataTable dt = bl.HienThiDS();
            //Tải dữ liệu Lớp
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                ListViewItem item = new ListViewItem(dt.Rows[i][0].ToString());
                item.SubItems.Add(dt.Rows[i][1].ToString());
                item.SubItems.Add(dt.Rows[i][2].ToString());
                lsvLop.Items.Add(item);
            }
        }
        public void LoadKhoa()
        {
            DataTable dt = dk.HienThiDS();
            //Tải dữ liệu Lớp
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                ListViewItem item = new ListViewItem(dt.Rows[i][0].ToString());
                item.SubItems.Add(dt.Rows[i][1].ToString());
                lsvKhoa.Items.Add(item);
            }
        }
        private void fmHome_Load(object sender, EventArgs e)
        {
            LoadSinhVien();
            LoadMonMH();
            LoadLop();
            LoadKhoa();
        }
        private void btnSuaSV_Click(object sender, EventArgs e)
        {
            string str;
            int row = this.lsvHTSV.SelectedItems[0].Index;
            str = this.lsvHTSV.Items[row].SubItems[0].Text;
            fmEditStudent fs = new fmEditStudent();
            fs.Show();
        }

        private void btnXoaSV_Click(object sender, EventArgs e)
        {

        }

        private void ExitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void btnThemMH_Click(object sender, EventArgs e)
        {
            fmAddMonHoc fm = new fmAddMonHoc();
            fm.Show();
        }
        private void btnRefrest_Click(object sender, EventArgs e)
        {
            
        }

        private void btnThemSV_Click(object sender, EventArgs e)
        {
            fmAddSutdent fm = new fmAddSutdent();
            fm.Show();
        }

        private void btnThemLop_Click(object sender, EventArgs e)
        {
            fmAddLop themlop = new fmAddLop();
            themlop.Show();
        }
        private void btnThemKhoa_Click(object sender, EventArgs e)
        {
            fmAddKhoa fm = new fmAddKhoa();
            fm.Show();
        }
        private void btnSuaLop_Click(object sender, EventArgs e)
        {
            try
            {
                string str;
                int row = this.lsvLop.SelectedItems[0].Index;
                str = this.lsvLop.Items[row].SubItems[0].Text;
                fmEditLop fs = new fmEditLop();
                fs.Show();
            }
            catch (Exception)
            {

                MessageBox.Show("Bạn Phải Chọn Đối Tượng Cần Sửa Đã","Thông Báo",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            
        }
        private void btnSuaKhoa_Click(object sender, EventArgs e)
        {
            try
            {
                string str;
                int row = this.lsvLop.SelectedItems[0].Index;
                str = this.lsvLop.Items[row].SubItems[0].Text;
                fmEditKhoa fs = new fmEditKhoa();
                fs.Show();
            }
            catch (Exception)
            {

                MessageBox.Show("Bạn Phải Chọn Đối Tượng Cần Sửa Đã", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXoaKhoa_Click(object sender, EventArgs e)
        {
            
        }

        private void btnXoaLop_Click(object sender, EventArgs e)
        {

        }

        private void btnXoaMH_Click(object sender, EventArgs e)
        {

        }

        private void btnXoaSV_Click_1(object sender, EventArgs e)
        {

        }
    }
}
