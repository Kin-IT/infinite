﻿using QLSV.DAO;
using QLSV.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLSV.BO
{
    class BOStudent
    {
        DAOStudent daosinhvien = new DAOStudent();
        public void ThemSinhVien(DTOStudent SV)
        {
            daosinhvien.ThemSinhVien(SV);
        }
        public void SuaSinhVien(DTOStudent SV)
        {
            daosinhvien.SuaSinhVien(SV);
        }
        public void XoaSinhVien(string MaSV)
        {
            daosinhvien.XoaSinhVien(MaSV);
        }
        public DataTable HienThiDS()
        {
            return daosinhvien.HienThiDS();
        }
    }
}
