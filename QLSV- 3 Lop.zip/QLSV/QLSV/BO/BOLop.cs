﻿using QLSV.DAO;
using QLSV.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLSV.BO
{
    class BOLop
    {
        DAOLop daomonhoc = new DAOLop();
        public void ThemL(DTOLop L)
        {
            daomonhoc.ThemLop(L);
        }
        public void SuaL(DTOLop L)
        {
            daomonhoc.SuaLop(L);
        }
        public void XoaL(string MaLop)
        {
            daomonhoc.XoaLop(MaLop);
        }
        public DataTable HienThiDS()
        {
            return daomonhoc.HienThiDS();
        }
    }
}
