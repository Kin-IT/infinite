﻿using QLSV.DAO;
using QLSV.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLSV.BO
{
    class BOMonHoc
    {
        DAOMonHoc daomonhoc = new DAOMonHoc();
        public void ThemMH(DTOMonHoc MH)
        {
            daomonhoc.ThemMonHoc(MH);
        }
        public void SuaMH(DTOMonHoc MH)
        {
            daomonhoc.SuaMonHoc(MH);
        }
        public void XoaMH(string MaMH)
        {
            daomonhoc.XoaMonHoc(MaMH);
        }
        public DataTable HienThiDS()
        {
            return daomonhoc.HienThiDS();
        }
    }
}
