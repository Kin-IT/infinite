﻿using QLSV.DAO;
using QLSV.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLSV.BO
{
    class BOKhoa
    {
        DAOKhoa dk = new DAOKhoa();
        public void ThemKhoa(DTOKhoa MH)
        {
            dk.ThemK(MH);
        }
        public void SuaKhoa(DTOKhoa MH)
        {
            dk.SuaK(MH);
        }
        public void XoaMH(string MaKhoa)
        {
            dk.XoaK(MaKhoa);
        }
        public DataTable HienThiDS()
        {
            return dk.HienThiDS();
        }
    }
}
