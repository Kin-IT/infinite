﻿using QLSV.BO;
using QLSV.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLSV
{
    public partial class fmEditStudent : Form
    {
        BOStudent bsv = new BOStudent();
        public fmEditStudent()
        {
            InitializeComponent();
        }
        private void fmEditStudent_Load(object sender, EventArgs e)
        {
            DataTable dt = bsv.HienThiDS();
            this.txbMaSV.Text = dt.Rows[0][0].ToString();
            this.txbTenSV.Text = dt.Rows[0][1].ToString();
            this.txbLop.Text = dt.Rows[0][2].ToString();
            
        }

        private void btnThucHien_Click(object sender, EventArgs e)
        {
            DTOStudent SV = new DTOStudent(txbMaSV.Text, txbTenSV.Text, txbLop.Text);
            try
            {
                bsv.SuaSinhVien(SV);
                MessageBox.Show("Sửa thành công");
                this.Close();
            }
            catch
            {
                MessageBox.Show("Sửa không thành công");
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
